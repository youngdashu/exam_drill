package zadDom.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Client {

    private String nickname;
    private InetAddress address;
    private InetAddress multicastAddress;
    private String ipAddress;
    private int portNumber;
    private Socket socketTCP;
    private DatagramSocket socketUDP;
    private MulticastSocket multicastSocket;
    private PrintWriter out;
    private BufferedReader in;
    private Scanner scanner = new Scanner(System.in);
    private String multicastIpAddress;
    private ClientReader clientReader;
    private Thread clientReaderThread;
    private UDPListener udpListener;
    private Thread UDPListenerThread;
    private UDPListener multicastSocketListener;
    private Thread multicastSocketListenerThread;


    public String getMulticastIpAddress() {
        return multicastIpAddress;
    }

    public void setMulticastIpAddress(String multicastIpAddress) {
        this.multicastIpAddress = multicastIpAddress;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public int getPortNumber() {
        return portNumber;
    }

    public void setPortNumber(int portNumber) {
        this.portNumber = portNumber;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public static byte[] ipAddressToByteArray(String ip){
        Object[] addressAsObjects = Arrays.stream(ip.split("\\.")).map(s -> Integer.valueOf(s).byteValue()).toArray();

        byte [] addressAsBytes = new byte[addressAsObjects.length];

        for (int i=0; i < addressAsBytes.length; i++)
            addressAsBytes[i] = (byte) addressAsObjects[i];

        return addressAsBytes;
    }

    public void connectToServer()  {

        try {
            address = InetAddress.getByAddress(ipAddressToByteArray(ipAddress));
        }  catch (UnknownHostException e) {
            System.out.println("Wrong host address!");
            return;
        }

        socketTCP = null;
        long waitTime = 5000L;

        while (socketTCP == null){
            try {
                socketTCP = new Socket(address, portNumber);
            } catch (IOException e) {
                System.out.println("Connection to server unavailable\nwaiting " + waitTime + "ms" + " and retrying connection");
                try {
                    this.wait(waitTime);
                } catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }
            }
        }

        try {

            out = new PrintWriter(socketTCP.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socketTCP.getInputStream()));

            socketUDP = new DatagramSocket();

        } catch (IOException ex){
            System.out.println("IO");
            ex.printStackTrace();
        } catch (Exception ex){
            ex.printStackTrace();
        }

        try {
            multicastSocket = new MulticastSocket(portNumber + 1);
            multicastSocket.joinGroup(new InetSocketAddress(
                    InetAddress.getByAddress(ipAddressToByteArray(multicastIpAddress)), portNumber + 1),
                    NetworkInterface.getByName("lo")
                    );
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            multicastAddress = InetAddress.getByAddress(ipAddressToByteArray(multicastIpAddress));
        } catch (UnknownHostException e) {
            System.out.println("Wrong multicast ip address");
            e.printStackTrace();
        }

    }

    public void registerToServer() throws IOException {
        out.println("R#" + nickname);
        String responseTCP =  in.readLine();
        if(responseTCP == null){
            System.out.println("Server connection lost");
            return;
        }

        byte [] UDPRegisterMessage = ("r#" + this.nickname).getBytes();
        socketUDP.send(new DatagramPacket(UDPRegisterMessage, UDPRegisterMessage.length, address, portNumber));


        if (responseTCP.startsWith("S")){
            System.out.println("Success registering to server");
        }else {
            String [] splitResponse = responseTCP.split("#", 2);
            if(splitResponse.length > 1){
                System.out.println(splitResponse[1]);
            }
        }

    }

    private class ClientReader implements Runnable{
        boolean isRunning = true;

        public void setRunning(boolean running) {
            isRunning = running;
        }

        @Override
        public void run() {
            while (isRunning){
                try {

                    String msg = in.readLine();

                    if(msg == null){
                        System.out.println("Connection with server lost");
                        break;
                    }
                    if (msg.startsWith("msg#")){
                        String [] splitMsg = msg.split("msg#", 2);
                        String msgWithSenderNickname = splitMsg[1];
                        String [] splitMsgWithSenderNickname = msgWithSenderNickname.split(":", 2);
                        System.out.println(splitMsgWithSenderNickname[0]);
                        System.out.println(splitMsgWithSenderNickname[1]);
                    }
                }catch (SocketException socketException){
                    return;
                }
                catch (IOException e) {
                    e.printStackTrace();

                }

            }
        }
    }

    private interface MessageFilter{
        boolean IsMessageAllowed(String message);
    }

    private class UDPListener implements Runnable{
        boolean isRunning = true;
        byte [] receiveBuffer = new byte[4096];
        private final DatagramSocket socket;
        private MessageFilter messageFilter = (message) -> {return true;};

        public UDPListener(DatagramSocket socket) {
            this.socket = socket;
        }

        public UDPListener(DatagramSocket socket, MessageFilter messageFilter) {
            this.socket = socket;
            this.messageFilter = messageFilter;
        }

        public void setRunning(boolean running) {
            isRunning = running;
        }



        @Override
        public void run() {
            while (isRunning){
                Arrays.fill(receiveBuffer, (byte)0);
                DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                try {
                    socket.receive(receivePacket);

                }catch (SocketException socketException){
                    return;
                }
                catch (IOException e) {
                    e.printStackTrace();
                    continue;
                }
                String receivedMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());
                if(messageFilter.IsMessageAllowed(receivedMessage))
                    System.out.println(receivedMessage);

            }

        }
    }

    public String readUDPMessageFromConsole(){
        StringBuilder stringBuilder = new StringBuilder();
        String readString;
        while (true){
            readString = scanner.nextLine();
            if(readString.equalsIgnoreCase("/u")){
                break;
            }
            stringBuilder.append(readString);
            stringBuilder.append("\n");
        }

        return stringBuilder.toString();
    }


    public void sendMessageUsingUDP(String messageToSend)  {
        byte [] sendBuffer = messageToSend.getBytes();
        DatagramPacket sendPacket = new DatagramPacket(sendBuffer, sendBuffer.length, address, portNumber);
        try {
            socketUDP.send(sendPacket);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendMessageUsingMulticast(String message){
        byte [] bytes = message.getBytes();
        DatagramPacket datagramPacketToSend = new DatagramPacket(bytes, bytes.length, multicastAddress, portNumber+1);
        try {
            socketUDP.send(datagramPacketToSend);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void startChat(){

        clientReader = new ClientReader();
        clientReaderThread = new Thread(clientReader);
        clientReaderThread.start();

        udpListener = new UDPListener(socketUDP);
        UDPListenerThread = new Thread(udpListener);
        UDPListenerThread.start();

        multicastSocketListener = new UDPListener(multicastSocket,
                (msg) -> ! msg.split(":", 2)[0].contains(this.nickname)
                );
        multicastSocketListenerThread = new Thread(multicastSocketListener);
        multicastSocketListenerThread.start();

        System.out.println("Type end to finish application");
        System.out.println("Choose message type:\nT for TCP\nU for UDP\nM for multicast\nand press enter");

        while (true){

            System.out.print("Type:\n");
            String type = scanner.nextLine();
            String msg;

            if (type.toLowerCase().startsWith("end"))
                break;

            if(type.length() < 1)
                continue;

            switch (type.toLowerCase().substring(0, 1)) {
                case "t" -> {
                    System.out.println("Type your message:");
                    msg = scanner.nextLine();
                    out.println(new Message(msg, this.nickname).TCPString());
                }
                case "u" -> {
                    System.out.println("Type /U to finish message:");
                    System.out.println("Type your message:");
                    msg = readUDPMessageFromConsole();
                    this.sendMessageUsingUDP(new Message(msg, this.nickname).UDPString());
                }
                case "m" -> {
                    System.out.println("Type your message:");
                    msg = scanner.nextLine();
                    this.sendMessageUsingMulticast(new Message(msg, this.nickname).multicastString());
                }
                default -> System.out.println("Unknown message type");
            }
        }



        this.endClient();

    }

    public static void clientTask(){

        Client client = new Client();
        Scanner scanner = new Scanner(System.in);

        Runtime.getRuntime().addShutdownHook(new Thread(client::endClient));

        System.out.println("Enter your nickname: ");
        String nickname = scanner.nextLine();
        while (nickname.equals("")){
            nickname = scanner.nextLine();
        }
        client.setNickname(nickname);

        String serverIpAddress;
        System.out.println("Enter server ip address or leave empty for default: ");
        serverIpAddress = scanner.nextLine();
        if(!serverIpAddress.equals("")) {
            while (!serverIpAddress.matches("[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}")) {
                System.out.println("Enter server ip address: ");
                serverIpAddress = scanner.nextLine();
            }
        } else{
            serverIpAddress = "127.0.0.1";
        }
        client.setIpAddress(serverIpAddress);

        String multicastIpAddress;
        System.out.println("Enter multicast ip address or leave empty for default: ");
        multicastIpAddress = scanner.nextLine();
        if(!multicastIpAddress.equals("")) {
            while (!multicastIpAddress.matches("[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}")) {
                System.out.println("Enter multicast ip address: ");
                multicastIpAddress = scanner.nextLine();
            }
        } else{
            multicastIpAddress = "230.0.0.0";
        }
        client.setMulticastIpAddress(multicastIpAddress);


        int portNumber = 9009;
        System.out.println("Enter port number or empty for default");
        String portNumberAsString = scanner.nextLine();
        if(! portNumberAsString.equals("")){
            while (! portNumberAsString.matches("[0-9]+"))
                System.out.println("Enter port number");
            portNumberAsString = scanner.nextLine();

            portNumber = Integer.parseInt(portNumberAsString);
        }

        client.setPortNumber(portNumber);

        System.out.println("Connecting to server...");

        client.connectToServer();

        try {
            client.registerToServer();
        } catch (IOException e) {
            System.out.println("Error registering to server");
            e.printStackTrace();
            return;
        }

        client.startChat();

    }

    public void endClient(){

        if(socketTCP != null){

            if(out != null){
                out.println("end#");
            }
            
            try {
                socketTCP.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
        if (socketUDP != null){
            socketUDP.close();
        }
        if(clientReader != null){
            clientReader.setRunning(false);
            clientReaderThread.interrupt();
        }
        if(udpListener != null){
            udpListener.setRunning(false);
            UDPListenerThread.interrupt();
        }
        if(multicastSocketListener != null){
            multicastSocketListener.setRunning(false);
            multicastSocketListenerThread.interrupt();
        }

        try {
            if(multicastSocket != null)
            multicastSocket.leaveGroup(new InetSocketAddress(
                            InetAddress.getByAddress(ipAddressToByteArray(multicastIpAddress)), portNumber + 1),
                    NetworkInterface.getByName("lo"));


        } catch (SocketException ignored){
        }
        catch (IOException e) {
            e.printStackTrace();
        }


        try {
            if(clientReaderThread != null)
                clientReaderThread.join(100);
            if(UDPListenerThread != null)
                UDPListenerThread.join(100);
            if(multicastSocketListenerThread != null)
                multicastSocketListenerThread.join(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {

        clientTask();
        System.exit(0);
    }

}