package zadDom.client;

public class Message {

    private String header;
    private String message;
    private String sender;

    public  Message(String message, String sender, String header){
        this.message = message;
        this.sender = sender;
        this.header = header;
    }

    public Message(String message, String sender){
        this(message, sender, "msg#");
    }


    public String TCPString() {
        return header + "Message from " + sender +":" + message;
    }

    public String UDPString(){ return header + sender + "#" + "Message from " + sender +":\n" + message;}

    public String multicastString(){return "Message from " + sender +":\n" + message;}
}
