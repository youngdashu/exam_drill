package zadDom;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.List;

public class ClientHandler implements Runnable {

    private Socket socketTcp;
    private DatagramSocket socketUdp;

    private final PrintWriter out;
    private final BufferedReader in;
    private final String nickname;
    private final List<ClientHandler> clients;
    private final Server server;

    private boolean isRunning = true;

    public ClientHandler(Socket socketTcp, DatagramSocket socketUdp, PrintWriter out, BufferedReader in, String nickname, List<ClientHandler> clients, Server server) {
        this.socketTcp = socketTcp;
        this.socketUdp = socketUdp;
        this.out = out;
        this.in = in;
        this.nickname = nickname;
        this.clients = clients;
        this.server = server;
    }

    public String getNickname() {
        return nickname;
    }

    public void sendMessageToClientsTcp(String msg){
        synchronized (this.clients) {
            this.clients.forEach(c -> {
                if (!c.equals(this))
                    c.sendMessageTcp(msg);
            });
        }
    }

    public void sendMessageTcp(String msg){
        out.println(msg);
    }

    public void sendMessageUDP(DatagramPacket datagramPacket) throws IOException {
        socketUdp.send(datagramPacket);
    }


    public void end(){

        if(socketUdp != null){
            socketUdp.close();
        }

        if(socketTcp != null){
            try {
                socketTcp.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        isRunning = false;


    }



    @Override
    public void run() {

        while (isRunning){

            try {

                String msgToSend = in.readLine();
                if(msgToSend == null){
                    break;
                }
                if(msgToSend.startsWith("msg#")) {
                    System.out.println("msg:" + msgToSend );
                    this.sendMessageToClientsTcp(msgToSend);
                }
                else if(msgToSend.startsWith("end#")) {
                    System.out.println("Client ends");
                    break;
                }

            } catch (SocketException socketException){

            }
            catch (IOException e) {
                e.printStackTrace();
            }

        }

        this.server.removeClient(this);

    }
}
