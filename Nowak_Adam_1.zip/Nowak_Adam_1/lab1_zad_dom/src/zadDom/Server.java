package zadDom;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class Server implements Runnable {

    private int portNumber = 9009;
    private ServerSocket serverSocket;
    private DatagramSocket datagramSocket;
    private final List<Thread> clientHandlerThreads = new LinkedList<>();
    private final List<ClientHandler> clientHandlers = new LinkedList<>();

    private final Map<String, InetAddress> clientToInetAddress = new HashMap<>();
    private final Map<String, Integer> clientToPortNumber = new HashMap<>();

    private DatagramSocketListener datagramSocketListener;
    private Thread datagramSocketListenerThread;

    private boolean isDatagramSocketListenerRunning = true;
    private boolean isMainLoopRunning = true;

    public InetAddress getClientInetAddress(String nickname){
        return this.clientToInetAddress.get(nickname);
    }

    public int getClientPortNumber(String nickname){
        return this.clientToPortNumber.get(nickname);
    }

    public void removeClient(ClientHandler clientHandler){
        synchronized (this.clientHandlers){
            this.clientHandlers.remove(clientHandler);
            this.clientToPortNumber.remove(clientHandler.getNickname());
            this.clientToInetAddress.remove(clientHandler.getNickname());
        }
    }

    private class DatagramSocketListener implements Runnable{

        @Override
        public void run() {
            byte [] receiveBuffer = new byte[4096];
            while (isDatagramSocketListenerRunning){
                Arrays.fill(receiveBuffer, (byte)0);
                DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                try {
                    datagramSocket.receive(receivePacket);
                } catch (SocketException ex){
                    if(! isDatagramSocketListenerRunning){
                        break;
                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
                String receivedMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("UDP msg received:\n" + receivedMessage);


                String [] splitMessage = receivedMessage.split("#", 3);

                if(splitMessage.length < 2){
                    continue;
                }
                String senderNickname = splitMessage[1];

                if(receivedMessage.toLowerCase().startsWith("r#")){
                    clientToInetAddress.putIfAbsent(senderNickname, receivePacket.getAddress());
                    clientToPortNumber.putIfAbsent(senderNickname, receivePacket.getPort());
                    continue;
                }
                if(splitMessage.length < 3)
                    continue;

                String message = splitMessage[2];


                byte [] bytesToSend = message.getBytes();
                synchronized (clientHandlers) {

                        clientHandlers.stream().parallel().filter(c -> ! c.getNickname().equals(senderNickname)).forEach(c
                                        ->{
                                    try {
                                        c.sendMessageUDP(new DatagramPacket(bytesToSend, bytesToSend.length,
                                                getClientInetAddress(c.getNickname()), getClientPortNumber(c.getNickname())));
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                        );

                }

            }
        }
    }

    @Override
    public void run(){

        try {
            serverSocket = new ServerSocket(portNumber);
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            datagramSocket = new DatagramSocket(portNumber);
        } catch (SocketException e) {
            e.printStackTrace();
        }

        datagramSocketListener = new DatagramSocketListener();
        datagramSocketListenerThread = new Thread(datagramSocketListener);
        datagramSocketListenerThread.start();

        while (isMainLoopRunning){

            try {
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client appeared");
                var out = new PrintWriter(clientSocket.getOutputStream(), true);
                var in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                try {
                    String registerLine = in.readLine();
                    if(registerLine == null)
                        continue;
                    System.out.println("Register message from client:\n" + registerLine);

                    if(registerLine.toLowerCase().startsWith("r") && registerLine.contains("#")) {
                        String[] splitRegisterLine = registerLine.split("#", 2);
                        String nickname = splitRegisterLine[1];

                        synchronized (clientHandlers) {

                            if (clientHandlers.stream().anyMatch(clientHandler -> clientHandler.getNickname().equals(nickname))) {
                                out.println("F#user with your username is already connected to the chat");
                                continue;
                            }

                            out.println("S");

                            ClientHandler clientHandler;
                            clientHandler = new ClientHandler(clientSocket, datagramSocket, out, in, nickname, clientHandlers, this);
                            Thread clientThread = new Thread(clientHandler);
                            clientThread.start();
                            clientHandlerThreads.add(clientThread);
                            clientHandlers.add(clientHandler);

                        }


                    } else{
                        throw new RuntimeException("Wrong message from client: " + registerLine);
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                } catch (RuntimeException ex){
                    System.out.println(ex.getMessage());
                    ex.printStackTrace();
                }

            } catch (Exception e) {
                System.out.println("error accepting socket");
                e.printStackTrace();
            }
        }

    }


    public void endServer(){
        System.out.println("Server shutting down");
        this.isDatagramSocketListenerRunning = false;
        this.isMainLoopRunning = false;
        synchronized (clientHandlers) {
            this.clientHandlers.forEach(ClientHandler::end);
            this.clientHandlerThreads.forEach(Thread::interrupt);
        }
    }


    public static void main(String[] args) {


        Server server = new Server();
        Runtime.getRuntime().addShutdownHook(new Thread(server::endServer));
        var serverThread = new Thread(server);
        serverThread.start();

    }


}
